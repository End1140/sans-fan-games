作者：我素系统、调零修罗、南省
Author: System, ZeroXilo, Crosu

请不要去骚扰前两位作者要游戏或者反馈bug、提交建议，因为他们早已经不在制作了
Please do not harass the first two authors who want to play games or report bugs or submit suggestions, because they are no longer making this game.

一阶段第一回合开始前按Tab可以切换新旧bgm和新旧台词
You can press "Tab" to change the bgm and the old words in phase 1 before the first round.

地狱模式（HELL MODE）只更新了第一阶段和第三阶段，未来可能会增加新内容
HELL MODE only updated the first and third phases, and new content may be added in the future.

三阶段颜料瓶内为“三阶段-Ex”阶段，不属于“第四阶段”
All the battles "in the bottles" are belong to the "Phase 3 - Ex" which does not belong to the "Phase 4".

游戏中按“G”可以得到一些食物，如果在进入三阶段-Ex阶段前按过G（不包括退了游戏），那么你的血量会变为333而不是198。（p.s 现在一直吃第一个pie不会让血条超出血上限了）
Press "G" in the game to get some food. If you press G before entering the Phase3-Ex (not including quitting the game), then your HP will become 333 instead of 198.(P.s. Now eating the first pie will not make the hp bar exceed the hp limit.)

本版本不包含“第四阶段”，所以版本号为0.3x
This version does not include the "Phase 4", so the version number is 0.3x.

下一个版本号为0.41，已经确认的内容包括扩充/更新三阶段弹幕池和增加第四阶段
The next version number will be 0.41. The confirmed content includes the update of the Phase3 attack type pool and the addition of the Phase 4.

如果打开游戏后发现在奇怪的地方，或者想移除存档的话，请使用“MERCY”中的“Reset”
If you find a strange place after opening the game, or if you want to remove the save files, please use the "Reset" in "MERCY".

如果你反编译了这个游戏，请不要把没有正式出现在这个版本中的内容公开，谢谢了。也不要因为看了这段话就去研究反编译什么的，真的谢谢
If you hacked this game, please do not spread the content that does not officially appear in this version. Thank you.

发布此游戏的视频请注明作者（第一行写的）
Please indicate the author when publishing the video of this game (written in the first line).

如果你发现了bug或者有某些更好的建议的话，请在这个工程的Demo版本的github界面提交issue，建议附带图片或者gif，如果是视频的话请打包成zip文件，在issue编辑界面直接将文件拖入文本输入的地方，它就会自己上传了。标题请用“【】”或者其他醒目的方式标明这是一个bug还是一个建议或者其他的东西（例如：“【bug】二阶段future有无缝攻击”、“【建议】将蓝莓前台词改为xxx”）
网址是：https://github.com/NsCrosu/DEMO-inksansGMS2/issues/new
不要加作者QQ，上不去的话找别人代发
=============================================
If you find a bug or have some better suggestions, please submit an issue on the github interface of the demo version of this project. It is recommended to attach an image or gif. If it is a video, please package it into a zip file and directly add it to the issue editing interface. Drag the file into the text input place and it will upload itself. For the title, please use "[ ]" or other eye-catching ways to indicate whether this is a bug or a suggestion or something else (for example: "[bug] Phase 2 future has a impossible attack", "[recommendation] change the blueberry foreground word to xxx")
The website is: https://github.com/NsCrosu/DEMO-inksansGMS2/issues/new

了解更多请关注 bilibili@ 南省Crosu
https://space.bilibili.com/51218197